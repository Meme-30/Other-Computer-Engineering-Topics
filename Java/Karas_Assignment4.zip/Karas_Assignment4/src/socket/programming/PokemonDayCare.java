package socket.programming;

import Utilities.Pokemon;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

/**
 * @author Jake D. Karas
 * Student Number: 8780
 * Date: 4/17/2023
 * This program establishes a day care server in which pokemon sent
 * from clients are checked into and checked out of
 */
public class PokemonDayCare extends Application {
    //Initialize GUI elements
    private TextArea ta = new TextArea();
    private int clientCount;

    /**
     * The method thad displays the server's GUI
     * @param primaryStage
     */
    @Override
    public void start(Stage primaryStage) {
        Scene scene = new Scene(new ScrollPane(ta), 400, 200);
        primaryStage.setTitle("Pokemon Day Care");
        primaryStage.setScene(scene);
        primaryStage.show();
        new Thread(()->runServer()).start();
    }

    /**
     * The method that starts the server and makes it
     * listen for clients
     */
    public void runServer() {
        try {
            ServerSocket serverSocket = new ServerSocket(8000);
            Platform.runLater(()-> ta.appendText("Server started at " + new Date() + '\n'));

            while(true) {
                // Listen for a new connection request
                Socket socket = serverSocket.accept();

                // Increment clientCount
                clientCount++;

                Platform.runLater(()-> {
                    // Display the number of clients connected
                    ta.appendText("New connection made with trainer. Total connections = " + clientCount + '\n');

                    // Find the client's host IP address
                    InetAddress inetAddress = socket.getInetAddress();
                    ta.appendText("Trainer's IP Address is " + inetAddress.getHostAddress() + '\n');
                });

                //Create and start a new thread for the connection
                new Thread(new HandleAClient(socket)).start();
            }
        }
        catch(IOException ex) {
            System.err.println(ex);
        }
    }

    /**
     * A support class that handles one client, which
     * has an instance for every client connected
     */
    class HandleAClient implements Runnable {
        private Socket socket;

        // Construct a thread
        public HandleAClient(Socket socket) {
            this.socket = socket;
        }

        // Run a thread
        public void run() {
            try {
                // Establish object input stream
                ObjectInputStream inputFromClient = new ObjectInputStream(socket.getInputStream());

                // Serve the client
                while(true) {
                    // Receive a Pokemon from the client
                    Pokemon pokemon = (Pokemon) inputFromClient.readObject();

                    // Check a Pokemon into the daycare (server)
                    if(pokemon.isCheckedIn() == true) {
                        //pokemon.checkIn();
                        Platform.runLater(()-> {
                            ta.appendText("Pokemon " + pokemon.getName() + " has been checked in.\n");
                        });
                    }

                    //Check a Pokemon out of the daycare (server)
                    else {
                        //pokemon.checkOut();
                        Platform.runLater(()-> {
                            ta.appendText("Pokemon " + pokemon.getName() + " has been checked out.\n");
                        });
                    }
                }
            }
            catch(IOException ex) {
                ex.printStackTrace();
            }
            catch(ClassNotFoundException ex) {
                System.err.println(ex);
            }
        }
    }

    /**
     * The main method is only needed for the IDE with limited
     * JavaFX support. Not needed for running from the command line.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
