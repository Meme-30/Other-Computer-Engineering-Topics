package exceptions;

/**
 * @author Karas
 * An exception thrown when attempting to
 * add the wrong type of child celestial
 * body to another's list of children
 */
public class InvalidCelestialBodyException extends Exception {
    /**
     * The constructor for the InvalidCelestialBodyException
     * @param argMessage
     */
    public InvalidCelestialBodyException(String argMessage) {
        super(argMessage);
    }
}
