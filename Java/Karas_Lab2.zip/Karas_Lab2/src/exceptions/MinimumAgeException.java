package exceptions;

/**
 * An exception that is thrown when the
 * person's age is less than the minimum
 * for the particular subclass called by
 */
public class MinimumAgeException extends Exception {
    /**
     * The constructor for the
     * MinimumAgeException class
     * @param argMessage
     */
    public MinimumAgeException (String argMessage) {
        super(argMessage);
    }
}
