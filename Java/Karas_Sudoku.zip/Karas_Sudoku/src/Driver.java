/**
 * @author Jake D. Karas
 * Student number: 8780
 * date 2/4/2023
 * This class contains the main method, which
 * creates a Sudoku object, initializes the values
 * of the sudoku array, and then interacts
 * with the user.
 */

import java.util.Scanner;

public class Driver {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Sudoku sudokuPuzzle = new Sudoku();
        sudokuPuzzle.display();
        boolean solvedFlag = false;
        int row = 0;
        int column = 0;
        int value = 0;
        while (solvedFlag == false) {
            System.out.print("Continue Playing (Y/N)? ");
            char yesOrNo = input.next().charAt(0);
            if (yesOrNo == 'N' || yesOrNo == 'n') {
                break;
            }
            else if (yesOrNo == 'Y' || yesOrNo == 'y') {
                System.out.print("Enter row (between 0 and 8): ");
                row = input.nextInt();
                System.out.print("Enter column (between 0 and 8): ");
                column = input.nextInt();
                if (sudokuPuzzle.isRowColumnValid(row, column) == false) {
                    System.out.println("Wrong Entry.");
                    sudokuPuzzle.display();
                    continue;
                }
                System.out.print("Enter value: ");
                value = input.nextInt();
                if (sudokuPuzzle.isValueValid(value) == false) {
                    System.out.println("Invalid Value.");
                    continue;
                }
                if (sudokuPuzzle.isEntryCorrect(row, column, value) == false) {
                    System.out.println("NOT Correct!");
                    sudokuPuzzle.display();
                }
                else {
                    System.out.println("Correct!");
                    sudokuPuzzle.puzzle[row][column] = value;
                    sudokuPuzzle.display();
                    if (sudokuPuzzle.isSolved() == true) {
                        solvedFlag = true;
                        System.out.println("Congratulations, you solved it!");
                    }
                }
            }
            else {
                System.out.println ("Invalid Input.");
            }
        }
    }
}
