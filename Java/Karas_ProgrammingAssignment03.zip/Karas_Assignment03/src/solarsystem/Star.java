package solarsystem;

import javafx.scene.paint.Color;

/**
 * @author Karas
 * A class to describe a star, inheriting
 * from the CelestialBody class
 */

public class Star extends CelestialBody {
    private int surfaceTemp;

    /**
     * The constructor for the Star class
     * @param name
     * @param surfaceTemp
     * @param color
     * @param radius
     */
    public Star(String name, int surfaceTemp, Color color, double radius) {
        super(name, "Star", color, radius);
        this.surfaceTemp = surfaceTemp;
    }

    /**
     * A getter method to return
     * the surfaceTemp
     * @return
     */
    public int getSurfaceTemp() {
        return surfaceTemp;
    }
}
