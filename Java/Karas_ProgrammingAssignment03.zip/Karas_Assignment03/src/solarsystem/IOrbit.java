package solarsystem;

/**
 * An interface that contains the getOrbit() method
 */
public interface IOrbit {
    /**
     * An abstract getter method that returns
     * which celestial body another is orbiting
     */
    public abstract CelestialBody getOrbit();
    public abstract void getOrbitInformation();
}
