import exceptions.DuplicateCelestialBodyException;
import exceptions.InvalidCelestialBodyException;
import solarsystem.CelestialBody;
import solarsystem.IOrbit;
import solarsystem.Moon;
import solarsystem.Planet;
import solarsystem.Star;

public class SolarSystem {
    public static void main(String[] args) {
        Star Sun = new Star("Sun", 5778);
        Planet Mercury = null;
        Planet Venus = null;
        Planet Earth = null;
        Planet Mars = null;
        Planet Jupiter = null;
        Planet Saturn = null;
        Planet Uranus = null;
        Planet Neptune = null;
        Planet ExceptionMaker = null;
        try {
            Mercury = new Planet("Mercury", Sun);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            Venus = new Planet("Venus", Sun);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            Earth = new Planet("Earth", Sun);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            Mars = new Planet("Mars", Sun);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            Jupiter = new Planet("Jupiter", Sun);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            Saturn = new Planet("Saturn", Sun);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            Uranus = new Planet("Uranus", Sun);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            Neptune = new Planet("Neptune", Sun);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            ExceptionMaker = new Planet("Neptune", Sun);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        Moon theMoon = null;
        Moon phobos = null;
        Moon deimos = null;
        Moon io = null;
        Moon europa = null;
        Moon ganymede = null;
        Moon callisto = null;
        Moon exceptionMaker2;
        try {
            theMoon = new Moon("The Moon", Earth);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            phobos = new Moon("Phobos", Mars);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            deimos = new Moon("Deimos", Mars);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            io = new Moon("Io", Jupiter);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            europa = new Moon("Europa", Jupiter);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            ganymede = new Moon("Ganymede", Jupiter);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            callisto = new Moon("Callisto", Jupiter);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        try {
            exceptionMaker2 = new Moon("Exception", Sun);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
        }
        Earth.getOrbit();
        theMoon.getOrbit();
    }
}
