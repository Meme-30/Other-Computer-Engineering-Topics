package solarsystem;

import exceptions.DuplicateCelestialBodyException;

import java.util.ArrayList;

/**
 * @author Karas
 * A class to describe a generic celestial body
 */

public class CelestialBody {
    private String name;
    private String type;
    private ArrayList<CelestialBody> children = new ArrayList<>();

    /**
     * The constructor for the CelestialBody class
     * @param name
     * @param type
     */
    public CelestialBody(String name, String type) {
        this.name = name;
        this.type = type;
    }

    /**
     * A getter method to return the name
     * of the celestial body
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * A getter method to return the type
     * of the celestial body
     * @return
     */
    public String getType() {
        return type;
    }

    /**
     * A method to add another celestial
     * body to the list of this one's
     * children, which can throw the
     * DuplicateCelestialBodyException
     * @param child
     * @throws DuplicateCelestialBodyException
     */
    public void add(CelestialBody child) throws DuplicateCelestialBodyException {
        for(int i = 0; i < this.children.size(); i++) {
            if(child.getName() == children.get(i).getName()) {
                throw new DuplicateCelestialBodyException("The planet "
                        + children.get(i).getName() + " is already in the collection");
            }
        }
        children.add(child);
        System.out.println("The " + child.getType() + " " + child.getName() +
                " was added successfully to " + this.getName() + ".");
    }

    /**
     * A getter method to return the
     * list of children
     * @return
     */
    public ArrayList<CelestialBody> getChildren() {
        return children;
    }
}
