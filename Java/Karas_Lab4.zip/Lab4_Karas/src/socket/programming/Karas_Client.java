package socket.programming;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 * @author Jake D. Karas
 * Student Number: 8780
 * Date: 4/10/2023
 *
 */

public class Karas_Client  extends Application {
    //Initialize GUI elements
    private TextField tfAnnualInterestRate = new TextField();
    private TextField tfNumOfYears = new TextField();
    private TextField tfLoanAmmount = new TextField();
    private Button btSubmit = new Button("Submit");
    private TextArea ta = new TextArea();

    //Initialize input and output streams
    DataOutputStream osToServer;
    DataInputStream isFromServer;

    /**
     * The method that displays the client's GUI, running exchangeDataWithServer
     * to obtain the monthly payment and total payment
     * @param primaryStage
     */
    @Override
    public void start(Stage primaryStage) {
        ta.setWrapText(true);
        GridPane gridPane = new GridPane();
        gridPane.add(new Label("Annual Interest Rate"), 0, 0);
        gridPane.add(new Label("Number of Years"), 0, 1);
        gridPane.add(new Label("Loan Amount"), 0, 2);
        gridPane.add(tfAnnualInterestRate, 1, 0);
        gridPane.add(tfNumOfYears, 1, 1);
        gridPane.add(tfLoanAmmount, 1, 2);
        gridPane.add(btSubmit, 2, 1);

        tfAnnualInterestRate.setAlignment(Pos.BASELINE_RIGHT);
        tfNumOfYears.setAlignment(Pos.BASELINE_RIGHT);
        tfLoanAmmount.setAlignment(Pos.BASELINE_RIGHT);

        BorderPane pane = new BorderPane();
        pane.setCenter(new ScrollPane(ta));
        pane.setTop(gridPane);

        //create scene and show primary stage
        Scene scene = new Scene(pane, 400, 200);
        primaryStage.setTitle("Karas Client");
        primaryStage.setScene(scene);
        primaryStage.show();


        btSubmit.setOnAction(e -> exchangeDataWithServer());

        try {
            Socket serverConnection = new Socket("localhost", 8000);
            //Create input stream to receive data from the server
            isFromServer = new DataInputStream(serverConnection.getInputStream());
            //Create output stream to transmit data to the server
            osToServer = new DataOutputStream(serverConnection.getOutputStream());
        }
        catch(IOException ex) {
            ta.appendText(ex.toString() + '\n');
        }
    }

    /**
     * The method that sends the data entered in the GUI to the server and receives the
     * monthly payment and total payment from the server
     */
    public void exchangeDataWithServer() {
        try {
            //get the annual interest rate, number of years, and loan amount from the text field
            double annualInterestRate = Double.parseDouble(tfAnnualInterestRate.getText().trim());
            int numOfYears = Integer.parseInt(tfNumOfYears.getText().trim());
            double loanAmount = Double.parseDouble((tfLoanAmmount.getText().trim()));

            //send variables to the server
            osToServer.writeDouble(annualInterestRate);
            osToServer.writeInt(numOfYears);
            osToServer.writeDouble(loanAmount);
            osToServer.flush();

            //get information from server -> monthly payment and total payment
            double monthlyPayment = isFromServer.readDouble();
            double totalPayment = isFromServer.readDouble();

            //print information to the text area of the client
            ta.appendText("Annual Interest Rate: " + annualInterestRate + '\n');
            ta.appendText("Number of Years: " + numOfYears + '\n');
            ta.appendText("Loan Amount: " + loanAmount + '\n');
            ta.appendText("monthlyPayment: " + monthlyPayment + '\n');
            ta.appendText("totalPayment: " + totalPayment + '\n');
        }
        catch(IOException ex) {
            System.err.println(ex);
        }
    }

    /**
     * The main method is only needed for the IDE with limited
     * JavaFX support. Not needed for running from the command line.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
