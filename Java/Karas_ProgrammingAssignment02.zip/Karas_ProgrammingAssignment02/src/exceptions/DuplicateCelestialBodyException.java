package exceptions;
/**
 * @author Karas
 * An exception thrown when a celestial body
 * already exists in another's children list
 */
public class DuplicateCelestialBodyException extends Exception {
    /**
     * The constructor for the DuplicateCelestialBodyException
     * @param argMessage
     */
    public DuplicateCelestialBodyException(String argMessage) {
        super(argMessage);
    }
}
