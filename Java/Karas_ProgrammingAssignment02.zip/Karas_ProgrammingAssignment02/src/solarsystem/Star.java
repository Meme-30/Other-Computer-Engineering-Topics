package solarsystem;

/**
 * @author Karas
 * A class to describe a star, inheriting
 * from the CelestialBody class
 */

public class Star extends CelestialBody {
    private int surfaceTemp;

    /**
     * The constructor for the Star class
     * @param name
     * @param surfaceTemp
     */
    public Star(String name, int surfaceTemp) {
        super(name, "Star");
        this.surfaceTemp = surfaceTemp;
    }

    /**
     * A getter method to return
     * the surfaceTemp
     * @return
     */
    public int getSurfaceTemp() {
        return surfaceTemp;
    }
}
