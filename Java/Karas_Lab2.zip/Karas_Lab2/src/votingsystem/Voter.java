package votingsystem;

import exceptions.MinimumAgeException;

/**
 * @author Karas
 * A class to describe a voter,
 * which extends the Person class
 */
public class Voter extends Person {
    private int voterId;
    private boolean voted = false;

    /**
     * The constructor for the Voter class
     * @param age
     * @param gender
     * @param firstName
     * @param lastName
     * @param politicalParty
     * @param voterId
     * @throws MinimumAgeException
     */
    public Voter(int age, char gender, String firstName, String lastName, String politicalParty, int voterId) throws MinimumAgeException {
        super(age, gender, firstName, lastName, politicalParty);
        if (age < 18) {
            throw new MinimumAgeException("Voter's age cannot be less than 18");
        }
        else {
            this.voterId = voterId;
        }
    }

    /**
     * A getter method for the voterID field
     * @return
     */
    public int getVoterId() {
        return voterId;
    }

    /**
     * A getter method for the voted field
     * @return
     */
    public boolean hasVoted() {
        return voted;
    }

    /**
     * A method that switches the
     * voted field to true
     */
    public void voted() {
        this.voted = true;
    }

    /**
     * An overridden getter method
     * for the voter's full name
     * @return
     */
    @Override
    public String getFullName() {
        return(firstName + " " + lastName);
    }
}
