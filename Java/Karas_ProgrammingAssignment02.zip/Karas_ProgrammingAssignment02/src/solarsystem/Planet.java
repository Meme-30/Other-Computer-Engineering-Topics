package solarsystem;

import exceptions.DuplicateCelestialBodyException;
import exceptions.InvalidCelestialBodyException;

/**
 * @author Karas
 * A class to define a planet, inheriting
 * from the CelestialBody class and implementing
 * the interface IOrbit
 */

public class Planet extends CelestialBody implements IOrbit {
    private CelestialBody orbits;

    /**
     * The constructor for the Planet class
     * @param name
     * @param orbits
     * @throws InvalidCelestialBodyException
     */
    public Planet(String name, CelestialBody orbits) throws InvalidCelestialBodyException {
        super(name, "Planet");
        if(orbits.getType() != "Star") {
            throw new InvalidCelestialBodyException("A planet must orbit a star.");
        }
        this.orbits = orbits;
        try {
            orbits.add(this);
        }
        catch(DuplicateCelestialBodyException dCBE) {
            System.out.println(dCBE);
        }
    }

    /**
     * A method to display the star the planet orbits
     */
    public void getOrbit() {
        System.out.println(this.getName() + " is orbiting the "
                + this.orbits.getType() + " " + this.orbits.getName() + ".");
    }
}
