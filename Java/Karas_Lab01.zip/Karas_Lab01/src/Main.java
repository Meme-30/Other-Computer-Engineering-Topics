import java.util.Scanner;

/**
 * @author Jake D. Karas
 * Student number: 8780
 * date 1/20/2023
 * This program calculates the sum between
 * num * random and limit * random
 * The class also contains the main method
 */

public class Main {

    /**
     * This is the main method calling sum
     * and asking for num and limit from the user
     * @param args
     */
    public static void main (String [] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a number:");
        int num = input.nextInt();
        System.out.println("Enter a limit:");
        int limit = input.nextInt();
        while (num > limit) {
            System.out.println("Error: Number must be less than or equal to limit.");
            System.out.println("Enter a number:");
            num = input.nextInt();
            System.out.println("Enter a limit:");
            limit = input.nextInt();
        }
        System.out.println("The sum is: " + sum (num, limit));
    }

    /**
     * This is the sum method that adds integer values
     * between num * random and limit * random
     * @param num
     * @param limit
     * @return returns the sum
     */
    public static int sum (int num, int limit) {
        int sum = 0;
        int random1 = (int)(3 + Math.random() * 6);
        System.out.println("Random number 1 is: " + random1);
        int random2 = (int)(3 + Math.random() * 6);
        System.out.println("Random number 2 is: " + random2);
        for (int i = random1 * num; i < random2 * limit; i++) {
            sum += i;
        }
        return sum;
    }

}
