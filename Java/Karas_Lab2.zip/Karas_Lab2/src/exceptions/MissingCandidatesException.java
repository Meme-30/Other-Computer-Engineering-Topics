package exceptions;

/**
 * An exception that is thrown when the
 * candidate list is null or empty
 */
public class MissingCandidatesException extends Exception {
    /**
     * The constructor for the
     * MissingCandidatesException class
     * @param argMessage
     */
    public MissingCandidatesException(String argMessage) {
        super(argMessage);
    }
}
