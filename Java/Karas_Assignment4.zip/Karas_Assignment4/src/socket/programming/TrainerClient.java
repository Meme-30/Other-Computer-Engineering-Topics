package socket.programming;

import Utilities.Pokemon;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * @author Jake D. Karas
 * Student Number: 8780
 * Date: 4/17/2023
 * This program creates a trainer client that can
 * connect to a day care server to check in and
 * check out pokemon from the day care
 */
public class TrainerClient extends Application {
    //Initialize GUI elements
    private String[] pokemonOptions = {"Bulbasaur", "Charmander", "Squirtle", "Pikachu"};
    private ComboBox<String> cbPokemonType = new ComboBox<>();
    private TextField tfPokemonName = new TextField();
    Button sendBtn = new Button("Send To Day Care");
    Button pickUpBtn = new Button("Pick Up From Day Care");

    // Initialize output stream
    ObjectOutputStream osToServer;
    Pokemon pokemon;

    /**
     * The method that displays the client GUI
     * @param primaryStage
     */
    @Override
    public void start(Stage primaryStage) {
        ObservableList<String> items = FXCollections.observableArrayList(pokemonOptions);
        cbPokemonType.getItems().addAll(items);
        GridPane pane = new GridPane();
        pane.add(new Label("Choose a Pokemon Type: "), 0, 0);
        pane.add(new Label("Pokemon's Name: "), 0, 1);
        pane.add(sendBtn, 0, 2);
        pane.add(cbPokemonType, 1, 0);
        pane.add(tfPokemonName, 1, 1);
        pane.add(pickUpBtn, 1, 2);

        tfPokemonName.setAlignment(Pos.BASELINE_RIGHT);
        sendBtn.setOnAction(new sendListener());
        pickUpBtn.setOnAction(new pickUpListener());
        pickUpBtn.setDisable(true);

        Scene scene = new Scene(pane, 400, 200);
        primaryStage.setTitle("Pokemon Trainer");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * A support class that makes the send button
     * interact with the server
     */
    private class sendListener implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent e) {
            try {
                Socket socket = new Socket("localhost", 8000);
                ObjectOutputStream toServer = new ObjectOutputStream(socket.getOutputStream());

                // Create a Pokemon object and send it to the server
                pokemon = new Pokemon(cbPokemonType.getValue(), tfPokemonName.getText());
                pokemon.checkIn();
                toServer.writeObject(pokemon);
                toServer.flush();
                toServer.reset();

                //Update the GUI
                cbPokemonType.setDisable(true);
                tfPokemonName.setDisable(true);
                sendBtn.setDisable(true);
                pickUpBtn.setDisable(false);
            }
            catch(IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * A support class that makes the pick up button
     * interact with the server
     */
    private class pickUpListener implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent e) {
            try {
                Socket socket = new Socket("localhost", 8000);
                ObjectOutputStream toServer = new ObjectOutputStream(socket.getOutputStream());
                pokemon.checkOut();
                toServer.writeObject(pokemon);
                toServer.flush();
                toServer.reset();

                //Update the GUI
                cbPokemonType.setDisable(false);
                tfPokemonName.setDisable(false);
                sendBtn.setDisable(false);
                pickUpBtn.setDisable(true);
            }
            catch(IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * The main method is only needed for the IDE with limited
     * JavaFX support. Not needed for running from the command line.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
