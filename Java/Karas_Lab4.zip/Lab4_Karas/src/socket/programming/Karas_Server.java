package socket.programming;

import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.*;
import java.util.Date;

import Utilities.Loan;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

/**
 * @author Jake D. Karas
 * Student Number: 8780
 * Date: 4/10/2023
 * This program establishes a server that computes the monthly payment and total payment of a loan from
 * input from a client and returns the calculated values to the client
 */

public class Karas_Server extends Application {
    private TextArea ta = new TextArea();

    /**
     * The method that displays the server's GUI
     * @param primaryStage
     */
    @Override
    public void start(Stage primaryStage) {
        Scene scene = new Scene(new ScrollPane(ta), 400, 200);
        primaryStage.setTitle("Karas Server");
        primaryStage.setScene(scene);
        primaryStage.show();
        new Thread(()->connectToClient()).start();
    }

    /**
     * The method that establishes a two-directional connection to a client
     */
    public void connectToClient() {
        try {
            ServerSocket serverSocket = new ServerSocket(8000);
            Platform.runLater(()-> ta.appendText("Karas Server has started at " + new Date() + '\n'));

            //listen to the client
            Socket connectToClient = serverSocket.accept();

            //print a connected message
            Platform.runLater(()-> ta.appendText("Connected to client " + "at " + new Date() + '\n'));

            //setup input stream
            DataInputStream isFromClient = new DataInputStream(connectToClient.getInputStream());

            //setup output stream
            DataOutputStream osToClient = new DataOutputStream(connectToClient.getOutputStream());

            while(true) {
                //read values from client
                double annualInterestRate = isFromClient.readDouble();
                int numOfYears = isFromClient.readInt();
                double loanAmount = isFromClient.readDouble();

                //compute monthly payment and total payment
                Loan mortgage = new Loan(annualInterestRate, numOfYears, loanAmount);
                double monthlyPayment = mortgage.getMonthlyPayment();
                double totalPayment = mortgage.getTotalPayment();

                //send data to client
                osToClient.writeDouble(monthlyPayment);
                osToClient.writeDouble(totalPayment);

                //Update the GUI
                Platform.runLater(()-> {
                    ta.appendText("Annual Interest Rate: " + annualInterestRate + '\n');
                    ta.appendText("Number of Years: " + numOfYears + '\n');
                    ta.appendText("Loan Amount: " + loanAmount + '\n');
                    ta.appendText("monthlyPayment: " + monthlyPayment + '\n');
                    ta.appendText("totalPayment: " + totalPayment + '\n');
                });

            }
        }
        catch(IOException ex) {
            System.err.println(ex);
        }
    }

    /**
     * The main method is only needed for the IDE with limited
     * JavaFX support. Not needed for running from the command line.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
