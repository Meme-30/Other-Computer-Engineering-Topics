import exceptions.DuplicateCelestialBodyException;
import exceptions.InvalidCelestialBodyException;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import panes.ErrorPane;
import panes.SolarSystemPane;
import solarsystem.CelestialBody;
import solarsystem.IOrbit;
import solarsystem.Moon;
import solarsystem.Planet;
import solarsystem.Star;
import static javafx.application.Application.launch;

/**
 * @author Jake D. Karas
 * Student Number: 8780
 * Date: 3/23/2023
 * This program creates a model
 * of the solar system, including
 * several moons, utilizing
 * JavaFX
 */

public class SolarSystem extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    public void triggerError(Stage stage, String message) {
        ErrorPane thisError = new ErrorPane(message);
        stage.setTitle("Error");
        Scene scene = new Scene(thisError);
        stage.setScene(scene);
        stage.show();
    }

    public void start(Stage primaryStage) {
        SolarSystemPane theSolarSystem = new SolarSystemPane();
        primaryStage.setTitle("The Solar System");
        Scene solarSystemScene = new Scene(theSolarSystem);
        primaryStage.setScene(solarSystemScene);
        primaryStage.show();
        Star sun = new Star("Sun", 5778, new Color(1, 0.996, 0.329, 1), 100);
        theSolarSystem.addStar(sun);
        Planet mercury = null;
        Planet venus = null;
        Planet earth = null;
        Planet mars = null;
        Planet jupiter = null;
        Planet saturn = null;
        Planet uranus = null;
        Planet neptune = null;
        Planet exceptionMaker = null;
        try {
            mercury = new Planet("Mercury", sun, new Color(0.502, 0.502, 0.502, 1), 10);
            theSolarSystem.addPlanet(mercury, 130);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }

        try {
            venus = new Planet("Venus", sun, new Color(0.918, 0.569, 0.2, 1), 20);
            theSolarSystem.addPlanet(venus, 200);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            earth = new Planet("Earth", sun, new Color(0.106, 0.059, 0.976, 1), 20);
            theSolarSystem.addPlanet(earth, 270);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            mars = new Planet("Mars", sun, new Color(0.890, 0.196, 0.133, 1), 15);
            theSolarSystem.addPlanet(mars, 340);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            jupiter = new Planet("Jupiter", sun, new Color(0.980, 0.925, 0.816, 1), 50);
            theSolarSystem.addPlanet(jupiter, 460);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            saturn = new Planet("Saturn", sun, new Color(0.980, 0.980, 0.839, 1), 40);
            theSolarSystem.addPlanet(saturn, 600);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            uranus = new Planet("Uranus", sun, new Color(0.392, 0.741, 0.976, 1), 35);
            theSolarSystem.addPlanet(uranus, 720);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            neptune = new Planet("Neptune", sun, new Color(0.282, 0.243, 0.529, 1), 35);
            theSolarSystem.addPlanet(neptune, 820);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        /*try {
            exceptionMaker = new Planet("Neptune", sun, new Color(0.282, 0.243, 0.529, 1), 35);
            theSolarSystem.addPlanet(exceptionMaker, 670);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }*/
        Moon theMoon = null;
        Moon phobos = null;
        Moon deimos = null;
        Moon io = null;
        Moon europa = null;
        Moon ganymede = null;
        Moon callisto = null;
        Moon titan = null;
        Moon enceladus = null;
        Moon titania = null;
        Moon oberon = null;
        Moon triton = null;
        Moon proteus = null;
        Moon exceptionMaker2;
        try {
            theMoon = new Moon("The Moon", earth, new Color(0.502, 0.502, 0.502, 1), 2);
            theSolarSystem.addMoon(theMoon, earth.getTheRadius() + 5);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            phobos = new Moon("Phobos", mars, new Color(0.718, 0.580, 0.502, 1), 2);
            theSolarSystem.addMoon(phobos, mars.getTheRadius() + 5);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            deimos = new Moon("Deimos", mars, new Color(0.863, 0.859, 0.741, 1), 2);
            theSolarSystem.addMoon(deimos, mars.getTheRadius() + 12);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            io = new Moon("Io", jupiter, new Color(0.639, 0.616, 0.247, 1), 2);
            theSolarSystem.addMoon(io, jupiter.getTheRadius() + 5);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            europa = new Moon("Europa", jupiter, new Color(0.643, 0.741, 0.835, 1), 2);
            theSolarSystem.addMoon(europa, jupiter.getTheRadius() + 12);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            ganymede = new Moon("Ganymede", jupiter, new Color(0.565, 0.467, 0.341, 1), 2);
            theSolarSystem.addMoon(ganymede, jupiter.getTheRadius() + 19);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            callisto = new Moon("Callisto", jupiter, new Color(0.314, 0.290, 0.231, 1), 2);
            theSolarSystem.addMoon(callisto, jupiter.getTheRadius() + 26);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            titan = new Moon("Titan", saturn, new Color(0.945, 0.875, 0.529, 1), 2);
            theSolarSystem.addMoon(titan, saturn.getTheRadius() + 5);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            enceladus = new Moon("Enceladus", saturn, new Color(0.933, 0.929, 0.909, 1), 2);
            theSolarSystem.addMoon(enceladus, saturn.getTheRadius() + 12);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            titania = new Moon("Titania", uranus, new Color(0.722, 0.675, 0.627, 1), 2);
            theSolarSystem.addMoon(titania, uranus.getTheRadius() + 5);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            oberon = new Moon("Oberon", uranus, new Color(0.522, 0.443, 0.455, 1), 2);
            theSolarSystem.addMoon(oberon, uranus.getTheRadius() + 12);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            triton = new Moon("Triton", neptune, new Color(0.820, 0.816, 0.796, 1), 2);
            theSolarSystem.addMoon(triton, neptune.getTheRadius() + 5);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        try {
            proteus = new Moon("Proteus", neptune, new Color(0.745, 0.745, 0.745, 1), 2);
            theSolarSystem.addMoon(proteus, neptune.getTheRadius() + 12);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }
        /*try {
            exceptionMaker2 = new Moon("Exception", sun, new Color (1, 1, 1, 1), 2);
            theSolarSystem.addMoon(exceptionMaker2, sun.getTheRadius() + 5);
        }
        catch(InvalidCelestialBodyException iCBE) {
            System.out.println(iCBE);
            primaryStage.close();
            Stage errorStage = new Stage();
            triggerError(errorStage, iCBE.toString());
        }*/
        earth.getOrbitInformation();
        theMoon.getOrbitInformation();
    }
}
