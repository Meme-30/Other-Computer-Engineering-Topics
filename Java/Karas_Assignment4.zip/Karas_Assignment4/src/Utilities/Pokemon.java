package Utilities;

import java.io.Serializable;
import java.util.Random;

/**
 * @author Jake D. Karas
 * Student Number: 8780
 * Date: 4/17/2023
 * This class defines a Pokemon that can be
 * transmitted from a trainer client to the
 * day care server
 */
public class Pokemon implements Serializable {
    private int pokemonID;
    private String pokemonType;
    private String name;
    private boolean checkedIn;


    /**
     * The constructor for the Pokemon class
     * @param pokemonType
     * @param name
     */
    public Pokemon(String pokemonType, String name) {
        this.pokemonType = pokemonType;
        this.name = name;
        Random rand = new Random();
        pokemonID = rand.nextInt(999999999);
        checkedIn = false;
    }

    /**
     * A getter method for the ID
     * @return
     */
    public int getPokemonID() {
        return pokemonID;
    }

    /**
     * A getter method for the type
     * @return
     */
    public String getPokemonType() {
        return pokemonType;
    }

    /**
     * A getter method for the name
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * A getter method for whether or
     * not it's checked in
     * @return
     */
    public boolean isCheckedIn() {
        return checkedIn;
    }

    /**
     * A method that sets the checkedIn
     * flag to true
     */
    public void checkIn() {
        checkedIn = true;
    }

    /**
     * A method that sets the checkedIn
     * flag to false
     */
    public void checkOut() {
        checkedIn = false;
    }
}
