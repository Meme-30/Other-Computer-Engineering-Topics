package solarsystem;

import exceptions.DuplicateCelestialBodyException;
import exceptions.InvalidCelestialBodyException;

/**
 * @author Karas
 * A class to define a moon, inheriting
 * from the CelestialBody class and implementing
 * the interface IOrbit
 */

public class Moon extends CelestialBody implements IOrbit {
    private CelestialBody orbits;

    /**
     * The constructor for the Moon class
     * @param name
     * @param orbits
     * @throws InvalidCelestialBodyException
     */
    public Moon(String name, CelestialBody orbits) throws InvalidCelestialBodyException {
        super(name, "Moon");
        if(orbits.getType() != "Planet") {
            throw new InvalidCelestialBodyException("A moon must orbit a planet.");
        }
        this.orbits = orbits;
        try {
            orbits.add(this);
        }
        catch(DuplicateCelestialBodyException dCBE) {
            System.out.println(dCBE);
        }
    }

    /**
     * A method to display the planet the moon orbits
     */
    public void getOrbit() {
        System.out.println(this.getName() + " is orbiting the "
                + this.orbits.getType() + " " + this.orbits.getName() + ".");
    }
}
