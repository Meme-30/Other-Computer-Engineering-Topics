package votingsystem;

/**
 * @author Karas
 * An abstract class to describe a general person
 * 2/10/2023
 */

public abstract class Person {
    private int age;
    private char gender;
    protected String firstName;
    protected String lastName;
    protected String politicalParty;

    /**
     * The constructor for the Person class
     * @param age
     * @param gender
     * @param firstName
     * @param lastName
     * @param politicalParty
     */
    public Person(int age, char gender, String firstName, String lastName, String politicalParty) {
        this.age = age;
        this.gender = gender;
        this.firstName = firstName;
        this.lastName = lastName;
        this.politicalParty = politicalParty;
    }

    /**
     * A getter method for the age field
     * @return
     */
    public int getAge() {
        return age;
    }

    /**
     * A getter method for the gender field
     * @return
     */
    public char getGender() {
        return gender;
    }

    /**
     * An abstract getter method for the
     * person's full name
     * @return
     */
    public abstract String getFullName();
}
