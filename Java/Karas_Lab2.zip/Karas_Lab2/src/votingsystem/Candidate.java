package votingsystem;

import exceptions.MinimumAgeException;

/**
 * @author Karas
 * A class to describe a candidate,
 * which extends the Person class
 */
public class Candidate extends Person {
    private int voteCount;

    /**
     * The constructor for the Candidate class
     * @param age
     * @param gender
     * @param firstName
     * @param lastName
     * @param politicalParty
     * @param voteCount
     * @throws MinimumAgeException
     */
    public Candidate(int age, char gender, String firstName, String lastName, String politicalParty, int voteCount) throws MinimumAgeException {
        super(age, gender, firstName, lastName, politicalParty);
        if (age < 25) {
            throw new MinimumAgeException("Candidate's age cannot be less than 25");
        }
        else {
            this.voteCount = voteCount;
        }
    }

    /**
     * A getter method for the voteCount field
     * @return
     */
    public int getVoteCount() {
        return voteCount;
    }

    /**
     * A method that increments
     * the voteCount field of
     * a candidate
     */
    public void incrementVoteCount() {
        this.voteCount++;
    }

    /**
     * An overridden getter method
     * for the candidate's full
     * name with their
     * party affiliation
     * @return
     */
    @Override
    public String getFullName() {
        if(politicalParty.equals("Democrat")) {
            return (firstName + " " + lastName + " - D");
        }
        else if(politicalParty.equals("Republican")) {
            return (firstName + " " + lastName + " - R");
        }
        else if(politicalParty.equals("Non-Affiliate")) {
            return (firstName + " " + lastName + " - NA");
        }
        return (firstName + " " + lastName);
    }
}
