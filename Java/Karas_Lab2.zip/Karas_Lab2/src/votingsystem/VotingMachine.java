package votingsystem;

import java.util.ArrayList;
import exceptions.MissingCandidatesException;

public class VotingMachine {
    public ArrayList<Candidate> candidates = new ArrayList<Candidate>();

    public VotingMachine(ArrayList<Candidate> candidates) throws MissingCandidatesException {
        this.candidates = candidates;
    }

    public void vote(Voter v, Candidate c) {
        if(v.hasVoted() == false) {
            c.incrementVoteCount();
            v.voted();
        }
    }
    public void tally() {
        int mostVotedIndex = 0;
        int maxVotes = 0;
        for(int i = 0; i < candidates.size(); i++) {
            System.out.println(candidates.get(i).getFullName() + " has " + candidates.get(i).getVoteCount() + " votes.");
            if (candidates.get(i).getVoteCount() > maxVotes) {
                mostVotedIndex = i;
                maxVotes = candidates.get(i).getVoteCount();
            }
        }
        System.out.println(candidates.get(mostVotedIndex).getFullName() + " won with " + candidates.get(mostVotedIndex).getVoteCount() + " votes.");
    }
}
