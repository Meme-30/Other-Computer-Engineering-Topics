/**
 * @author Jake D. Karas
 * Student number: 8780
 * date 2/4/2023
 * This class defines a Sudoku object,
 * containing all the methods called
 * by the driver class.
 */

public class Sudoku {
    public int[][] puzzle;

    /**
     * This is the constructor for the sudoku puzzle:
     */
    public Sudoku() {
        puzzle = new int[][] {{5, 3, 4, 0, 7, 8, 9, 1, 2}, {6, 7, 0, 1, 9, 5, 3, 4, 8}, {1, 9, 8, 3, 4, 2, 5, 0, 7}, {8, 0, 9, 7, 6, 1, 4, 2, 3}, {4, 2, 6, 8, 0, 3, 7, 9, 0}, {7, 1, 3, 9, 2, 4, 8, 5, 6}, {9, 0, 1, 5, 3, 7, 2, 8, 4}, {2, 8, 7, 4, 1, 9, 6, 0, 5}, {3, 4, 5, 2, 8, 6, 1, 7, 9}};
    }

    /**
     * This is the display method, which
     * formats and prints the sudoku puzzle.
     */
    public void display() {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                System.out.print(puzzle[i][j] + " ");
                if (j == 2 || j == 5) {
                    System.out.print("| ");
                }
            }
            System.out.print('\n');
            if (i == 2 || i == 5) {
                System.out.println("------+-------+------");
            }
        }
    }

    /**
     * This is the isSolved method, which
     * determines whether the puzzle
     * is solved based on if there's any
     * zeroes remaining.
     * @return
     */
    public boolean isSolved() {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (puzzle[i][j] == 0) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * This is the isValueValid method,
     * which determines if the user's
     * inputted value is between 1 and 9.
     * @param value
     * @return
     */

    public boolean isValueValid(int value) {
        if (value >= 1 && value <= 9) {
            return true;
        }
        return false;
    }

    /**
     * This is the isRowColumnValid
     * method, which determines if the
     * row and column the user have selected
     * are within limits and whether the
     * value at that point is a zero.
     * @param row
     * @param column
     * @return
     */
    public boolean isRowColumnValid(int row, int column) {
        if (row >= 0 && row <= 8 && column >= 0 && column <= 8) {
            if (puzzle[row][column] == 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * This is the isEntryCorrect method,
     * which determines if the value
     * entered to replace a zero is
     * correct according to
     * Sudoku rules.
     * @param row
     * @param column
     * @param value
     * @return
     */
    public boolean isEntryCorrect(int row, int column, int value) {
        for (int i = 0; i < 9; i++) {
            if (value == puzzle[i][column]) {
                return false;
            }
        }
        for (int j = 0; j < 9; j++) {
            if (value == puzzle[row][j]) {
                return false;
            }
        }
        return true;
    }
}

