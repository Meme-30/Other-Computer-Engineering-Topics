package solarsystem;

import exceptions.DuplicateCelestialBodyException;
import exceptions.InvalidCelestialBodyException;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import panes.ErrorPane;

/**
 * @author Karas
 * A class to define a planet, inheriting
 * from the CelestialBody class and implementing
 * the interface IOrbit
 */

public class Planet extends CelestialBody implements IOrbit {
    private CelestialBody orbits;

    /**
     * The constructor for the Planet class
     * @param name
     * @param orbits
     * @param color
     * @param radius
     * @throws InvalidCelestialBodyException
     */
    public Planet(String name, CelestialBody orbits, Color color, double radius) throws InvalidCelestialBodyException {
        super(name, "Planet", color, radius);
        if(orbits.getType() != "Star") {
            throw new InvalidCelestialBodyException("A planet must orbit a star.");
        }
        this.orbits = orbits;
        try {
            orbits.add(this);
        }
        catch(DuplicateCelestialBodyException dCBE) {
            System.out.println(dCBE);
            Stage errorStage = new Stage();
            triggerError(errorStage, dCBE.toString());
        }
    }

    /**
     * A method to obtain the star the planet orbits
     */
    public CelestialBody getOrbit() {
        return this.orbits;
    }

    /**
     * A method to display the star the planet orbits
     */
    public void getOrbitInformation() {
        System.out.println(this.getName() + " is orbiting the "
                + this.orbits.getType() + " " + this.orbits.getName() + ".");
    }

    /**
     * A method to trigger an error pane to
     * appear for a DCBE
     * @param stage
     * @param message
     */
    public void triggerError(Stage stage, String message) {
        ErrorPane thisError = new ErrorPane(message);
        stage.setTitle("Error");
        Scene scene = new Scene(thisError);
        stage.setScene(scene);
        stage.show();
    }
}
