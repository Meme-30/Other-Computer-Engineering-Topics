import exceptions.MinimumAgeException;
import exceptions.MissingCandidatesException;
import votingsystem.Candidate;
import votingsystem.Voter;
import votingsystem.VotingMachine;
import java.util.ArrayList;

public class Election {
    public static void main(String[] args) {
        ArrayList<Candidate> listOfCandidates = new ArrayList<>();
        Candidate candidate1, candidate2, candidate3, candidate4 = null;
        try {
            candidate1 = new Candidate(45, 'M', "Dolan", "Trimp", "Republican", 0);
            listOfCandidates.add(candidate1);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        try {
            candidate2 = new Candidate(57, 'M', "Joel", "Boden", "Democrat", 0);
            listOfCandidates.add(candidate2);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        try {
            candidate3 = new Candidate(32, 'F', "Nonya", "Business", "Non-Affiliate", 0);
            listOfCandidates.add(candidate3);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        try {
            candidate4 = new Candidate(22, 'M', "Weirdo", "McWeirdo", "Non-Affiliate", 0);
            listOfCandidates.add(candidate4);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        ArrayList<Voter> voters = new ArrayList<>();
        Voter voter1, voter2, voter3, voter4, voter5, voter6, voter7, voter8, voter9, voter10, voter11 = null;
        try {
            voter1 = new Voter(32, 'M', "Voter", "One", "Republican", 1);
            voters.add(voter1);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        try {
            voter2 = new Voter(32, 'M', "Voter", "Two", "Republican", 2);
            voters.add(voter2);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        try {
            voter3 = new Voter(32, 'M', "Voter", "Three", "Republican", 3);
            voters.add(voter3);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        try {
            voter4 = new Voter(32, 'M', "Voter", "Four", "Republican", 4);
            voters.add(voter4);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        try {
            voter5 = new Voter(32, 'M', "Voter", "Five", "Republican", 5);
            voters.add(voter5);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        try {
            voter6 = new Voter(32, 'M', "Voter", "Six", "Republican", 6);
            voters.add(voter6);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        try {
            voter7 = new Voter(32, 'M', "Voter", "Seven", "Democrat", 7);
            voters.add(voter7);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        try {
            voter8 = new Voter(32, 'M', "Voter", "Eight", "Democrat", 8);
            voters.add(voter8);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        try {
            voter9 = new Voter(32, 'M', "Voter", "Nine", "Democrat", 9);
            voters.add(voter9);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        try {
            voter10 = new Voter(32, 'M', "Voter", "Ten", "Non-Affiliate", 10);
            voters.add(voter10);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        try {
            voter11 = new Voter(17, 'M', "Voter", "Eleven", "Non-Affiliate", 11);
            voters.add(voter11);
        }
        catch(MinimumAgeException minAgeEx) {
            System.out.println(minAgeEx);
        }
        VotingMachine machine = null;
        try {
            machine = new VotingMachine(listOfCandidates);
            for(int i = 0; i <= 5; i++) {
                machine.vote(voters.get(i), listOfCandidates.get(0));
            }
            for(int i = 6; i <= 8; i++) {
                machine.vote(voters.get(i), listOfCandidates.get(1));
            }
            machine.vote(voters.get(9), listOfCandidates.get(2));
        }
        catch(MissingCandidatesException missCandEx) {
            System.out.println(missCandEx);
        }
        machine.tally();
    }
}
