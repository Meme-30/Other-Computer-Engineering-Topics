import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class movingCircle extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Pane pane = new Pane();
        Circle circle = new Circle(100, 100, 50);
        pane.getChildren().add(circle);
        circle.setStroke(Color.BLACK);
        circle.setFill(Color.WHITE);

        //code to make the scene
        Scene scene = new Scene(pane, 800, 500);
        primaryStage.setTitle("Lab 3"); //Set the stage title
        primaryStage.setScene(scene); //Place the scene in the stage
        primaryStage.show(); //Display the stage

        // code to change color and move the circle
        scene.setOnMousePressed(e -> {
           if(e.getButton() == MouseButton.PRIMARY) {
               circle.setFill(Color.BLACK);
           }
        });
        scene.setOnMouseReleased(e -> {
            if(e.getButton() == MouseButton.PRIMARY) {
                circle.setFill(Color.WHITE);
            }
        });
        scene.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.LEFT) {
                circle.setCenterX(circle.getCenterX() - 10);
            }
            else if (e.getCode() == KeyCode.RIGHT) {
                circle.setCenterX(circle.getCenterX() + 10);
            }
            else if (e.getCode() == KeyCode.DOWN) {
                circle.setCenterY(circle.getCenterY() + 10);
            }
            else if (e.getCode() == KeyCode.UP) {
                circle.setCenterY(circle.getCenterY() - 10);
            }
        });
    }
}
