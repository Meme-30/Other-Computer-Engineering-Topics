package panes;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class ErrorPane extends VBox {
    String errorMessage;
    Button btOk = new Button("Ok");
    OKHandlerClass okHandler = new OKHandlerClass();

    /**
     * The constructor for an error pane
     * @param errorMessage
     */
    public ErrorPane(String errorMessage) {
        this.setAlignment(Pos.CENTER);
        this.setPadding(new Insets(15, 100, 15, 100));
        this.errorMessage = errorMessage;
        Label theMessage = new Label(errorMessage);
        this.getChildren().add(theMessage);
        this.getChildren().add(btOk);
        btOk.setOnAction(okHandler);
    }

    /**
     * Ok button handler to make the
     * scene close upon clicking
     * the button
     */
    class OKHandlerClass implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent e) {
            Platform.exit();
        }
    }
}
