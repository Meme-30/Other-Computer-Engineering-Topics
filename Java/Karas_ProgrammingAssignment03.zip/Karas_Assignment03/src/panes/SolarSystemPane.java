package panes;

import javafx.geometry.Insets;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import solarsystem.Moon;
import solarsystem.Planet;
import solarsystem.Star;

public class SolarSystemPane extends Pane {
    public SolarSystemPane() {
        this.setPadding(new Insets(420, 420, 420, 420));
        this.setBackground(new Background(new BackgroundFill(Color.BLACK, new CornerRadii(0), new Insets(0))));
    }

    public void addStar(Star star) {
        star.setCenterX(0);
        star.setCenterY(0);
        star.setRadius(star.getTheRadius());
        star.setStroke(star.getColor());
        star.setFill(star.getColor());
        this.getChildren().add(star);
    }

    public void addPlanet(Planet planet, double distance) {
        Circle orbitRing = new Circle();
        orbitRing.setCenterX(0);
        orbitRing.setCenterY(0);
        orbitRing.setRadius(distance);
        orbitRing.setStroke(new Color(0.471, 0.471, 0.471, 1));
        orbitRing.setFill(new Color(0, 0, 0, 0));
        this.getChildren().add(orbitRing);
        planet.setCenterX(distance * Math.cos(45));
        planet.setCenterY(distance * Math.sin(45));
        planet.setRadius(planet.getTheRadius());
        planet.setStroke(planet.getColor());
        planet.setFill(planet.getColor());
        this.getChildren().add(planet);
    }

    public void addMoon(Moon moon, double distance) {
        Circle orbitRing = new Circle();
        orbitRing.setCenterX(moon.getOrbit().getCenterX());
        orbitRing.setCenterY(moon.getOrbit().getCenterY());
        orbitRing.setRadius(distance);
        orbitRing.setStroke(new Color(0.471, 0.471, 0.471, 1));
        orbitRing.setFill(new Color(0, 0, 0, 0));
        this.getChildren().add(orbitRing);
        moon.setCenterX(moon.getOrbit().getCenterX() + distance * Math.cos(45));
        moon.setCenterY(moon.getOrbit().getCenterY() + distance * Math.sin(45));
        moon.setRadius(moon.getTheRadius());
        moon.setStroke(moon.getColor());
        moon.setFill(moon.getColor());
        this.getChildren().add(moon);
    }
}
